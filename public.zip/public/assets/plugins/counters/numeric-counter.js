$(function(){
	$('.counter').countUp();
});