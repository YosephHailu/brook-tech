// ______________ PerfectScrollbar
const ps2 = new PerfectScrollbar('.vscroll',{
	useBothWheelAxes:true,
	suppressScrollX:true,
});
// ______________ PerfectScrollbar
const ps3 = new PerfectScrollbar('.vscroll1',{
	useBothWheelAxes:true,
	suppressScrollX:true,
});