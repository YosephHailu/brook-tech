
var keywords = [
	'1BHK','2BHK','3BHK','Apartment','AutoMobile','Backery',
	'Beauty','BestCar','Cafe','Cakes','Cinema','Classes','Coaching','College','Consultancy','Deserts','Dinner','Education',
	'Events','Facials','Fitness','Food','Gym','Hairsaloon','HairSpa','Health','HealthyBody','Home','Hotel','Hotels','IceCreams', 
	'Meditation','MobileStore','ModelCars','NonVeg','Parlour','RealEstate','Relaxation','Restaurant','Shop&Store','Spa','Study', 
	'Tours&Travels','University','Veg','Yoga'
];
$('.keywords-input').autocomplete({
	source:[keywords]
});
